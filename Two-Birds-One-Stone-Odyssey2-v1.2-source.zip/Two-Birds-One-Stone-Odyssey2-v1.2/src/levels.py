"""Fifty puzzles in Odyssey 2 coordinates, plus provenance for the first ten.

Entity: x, y, left limit, right limit, signed speed in 1/64 pixel per frame.
The hardware uses 8x16 birds, 8x14 sparks/blocks, and a 3x4 stone.
"""
from pathlib import Path
import re

def original_levels(path):
    s=Path(path).read_text()
    numbers=list(map(int,re.search(r'LEVELDATA\[321\] DATA(.*?);',s,re.S).group(1).replace('\n','').split(',')))
    out=[];p=0
    clamp=lambda x:max(10,min(148,round((x-2048)/16+8)))
    for k in range(10):
        birds,sparks,boxes,wires=numbers[p:p+4];p+=4;entities=[]
        for i in range(birds+sparks):
            x,y,lo,hi,d,v=numbers[p:p+6];p+=6
            yy=(round(((y-188)/10+48)/24)*24-16) if i<birds else round((y-188)/10+40)//2*2
            speed=round(v*4/16/60*64)*(1 if d==1 else -1 if d==2 else 0)
            entities.append([clamp(x),yy,clamp(lo),clamp(hi),speed])
        block=[]
        for i in range(boxes):
            x,y=numbers[p:p+2];p+=2
            block.append([max(10,min(148,round((x-2048)/16+12))),round((y+48-188)/10+24)//2*2])
        p+=wires
        if k==8:
            # The Atari's off-screen train spans over twice the visible field.
            # Keep its seven moving hazards, with a common patrol and staggered starts.
            for i,e in enumerate(entities[birds:]):e[:]=[12+i*20,148,10+i*20,26+i*20,13]
        if k==7:
            for i,e in enumerate(entities[birds:]):e[:]=[15+i*8,148,15+i*8,114+i*8,24]
        out.append(dict(name=['One line','Timing','Crossing','Return to sender','Three circuits','Live wire','Double live wire','The convoy','Power station','Four flights'][k],birds=sorted(entities[:birds],key=lambda e:e[1]),sparks=entities[birds:],boxes=block,instant=k==7))
    assert p==321
    return out

def e(x,y,lo=None,hi=None,s=0):return [x,y,x if lo is None else lo,x if hi is None else hi,s]

def new_levels():
    return [
      dict(name='Scissor flight',birds=[e(40,56,30,125,19),e(120,104,30,125,-25)],sparks=[e(70,148,15,145,13)],boxes=[]),
      dict(name='Two return trips',birds=[e(40,104),e(120,104),e(80,32)],sparks=[],boxes=[[40,64],[120,64]]),
      dict(name='Three in a column',birds=[e(25,32,20,140,13),e(80,80,20,140,-19),e(135,128,20,140,25)],sparks=[],boxes=[]),
      dict(name='The narrow opening',birds=[e(80,56)],sparks=[e(24,148,20,96,13),e(48,148,44,120,13),e(72,148,68,144,13)],boxes=[]),
      dict(name='Twin circuits',birds=[e(30,80,24,55,16),e(55,128,24,55,-16),e(105,80,100,132,-20),e(132,128,100,132,20)],sparks=[e(70,152,64,90,13)],boxes=[[37,50],[113,50]]),
      dict(name='Cross the current',birds=[e(30,56,20,140,27),e(130,104,20,140,-17)],sparks=[e(30,148,12,74,19),e(104,148,84,146,19)],boxes=[]),
      dict(name='The relay',birds=[e(28,104),e(76,104),e(124,104),e(104,32)],sparks=[e(50,150,12,145,11)],boxes=[[28,64],[76,64],[124,64]]),
      dict(name='Six wings',birds=[e(24,56,20,140,16),e(74,56,20,140,16),e(124,56,20,140,16),e(24,128,20,140,-16),e(74,128,20,140,-16),e(124,128,20,140,-16)],sparks=[],boxes=[[25,32],[75,32],[125,32]]),
      dict(name='Last live wire',birds=[e(30,56,24,138,23),e(130,104,24,138,-23)],sparks=[e(20,148,12,50,15),e(66,148,58,96,15),e(112,148,104,142,15)],boxes=[]),
      dict(name='One stone to rule them all',birds=[e(30,80,24,50,17),e(50,128,24,50,-17),e(70,80,65,91,-19),e(91,128,65,91,19),e(112,80,106,137,21),e(137,128,106,137,-21)],sparks=[e(60,154,54,104,11)],boxes=[[33,48],[75,48],[117,48]]),
    ]

def expansion_levels():
    """Thirty authored stages; each combines timing, safe lanes, or caught returns."""
    return [
      dict(name='Window seat',birds=[e(54,56,48,112,21),e(108,104,48,112,-25)],sparks=[e(28,148,12,44,19),e(130,148,116,148,-19)],boxes=[]),
      dict(name='Return address',birds=[e(55,32),e(30,104),e(80,104),e(130,104)],sparks=[],boxes=[[30,64],[80,64],[130,64]]),
      dict(name='Switchback',birds=[e(25,32,20,140,19),e(138,80,20,140,-23),e(21,128,20,140,27)],sparks=[],boxes=[]),
      dict(name='The wicket',birds=[e(64,56,64,96,17),e(96,104,64,96,-17)],sparks=[e(16,148,12,40,17),e(48,148,44,72,19),e(96,148,88,116,-21),e(128,148,120,148,-23)],boxes=[]),
      dict(name='High and low',birds=[e(40,56),e(120,56),e(40,128),e(120,128)],sparks=[e(70,148,58,96,19)],boxes=[[40,32],[120,32]]),
      dict(name='The tollgate',birds=[e(104,32),e(30,104),e(80,104),e(130,104)],sparks=[e(20,148,12,48,17),e(70,148,62,98,-19),e(132,148,112,148,21)],boxes=[[30,64],[80,64],[130,64]]),
      dict(name='Tightropes',birds=[e(40,56,40,120,29),e(120,104,40,120,-29)],sparks=[e(78,148,48,112,17)],boxes=[]),
      dict(name='Stepping stones',birds=[e(30,56),e(65,80),e(100,104),e(135,128)],sparks=[],boxes=[[30,32],[65,56],[100,80],[135,104]]),
      dict(name='The sweeper',birds=[e(80,56),e(80,104)],sparks=[e(20,148,20,140,27),e(140,148,20,140,-19)],boxes=[]),
      dict(name='Six returns',birds=[e(26,80,24,43,19),e(76,80,74,93,23),e(126,80,124,143,29),e(42,128,24,43,-19),e(92,128,74,93,-23),e(142,128,124,143,-29)],sparks=[],boxes=[[34,48],[84,48],[134,48]]),
      dict(name='Split decision',birds=[e(60,32,40,120,19),e(100,32,40,120,-19),e(42,104),e(118,104)],sparks=[e(70,148,12,145,17)],boxes=[[42,64],[118,64]]),
      dict(name='Headwind',birds=[e(131,32,24,140,-31),e(104,80,24,140,-23),e(86,128,24,140,-17)],sparks=[],boxes=[]),
      dict(name='Safe pocket',birds=[e(60,56,52,92,17),e(100,104,72,112,-17)],sparks=[e(24,148,20,52,21),e(76,148,64,96,-23),e(132,148,108,140,25)],boxes=[]),
      dict(name='Over and under',birds=[e(80,32),e(40,80),e(120,80),e(40,128),e(120,128)],sparks=[e(20,152,12,36,13),e(52,152,44,68,17),e(92,152,84,108,-19),e(124,152,116,144,-23)],boxes=[[40,56],[120,56]]),
      dict(name='Two step',birds=[e(40,56,40,120,16),e(120,56,40,120,-16),e(40,128),e(120,128)],sparks=[],boxes=[[40,96],[120,96]]),
      dict(name='Escalator',birds=[e(30,56),e(80,104),e(130,128,112,140,-19)],sparks=[e(26,148,12,64,17),e(120,148,90,146,-21)],boxes=[[30,32],[80,80]]),
      dict(name='Crosswind',birds=[e(24,56,20,140,35),e(132,104,20,140,-33)],sparks=[e(22,148,12,70,27),e(116,148,88,146,-23)],boxes=[]),
      dict(name='Triple gates',birds=[e(80,32),e(80,80),e(80,128)],sparks=[e(30,56,12,140,19),e(120,104,12,140,-23),e(50,152,12,140,17)],boxes=[]),
      dict(name='Long return',birds=[e(32,56),e(80,56),e(128,56),e(32,128),e(80,128),e(128,128)],sparks=[e(20,152,12,70,19),e(120,152,88,146,-23)],boxes=[[32,32],[80,32],[128,32]]),
      dict(name='Five flights',birds=[e(80,32),e(24,104),e(56,104),e(104,104),e(136,104)],sparks=[e(40,148,12,70,21),e(104,148,88,146,-25)],boxes=[[24,64],[56,64],[104,64],[136,64]]),
      dict(name='Pendulum',birds=[e(30,56,24,138,33),e(130,104,24,138,-33)],sparks=[e(28,148,12,50,21),e(80,148,60,98,-25),e(132,148,108,146,29)],boxes=[]),
      dict(name='Narrow shelves',birds=[e(30,56),e(125,56),e(55,80),e(100,80),e(30,128),e(125,128)],sparks=[],boxes=[[30,32],[125,32],[55,56],[100,56]]),
      dict(name='Drift window',birds=[e(62,32,60,100,11),e(99,80,60,100,-15),e(63,128,60,100,19)],sparks=[e(20,148,12,40,19),e(56,148,44,72,-23),e(96,148,88,116,25),e(132,148,120,148,-29)],boxes=[]),
      dict(name='Relay race',birds=[e(80,32),e(24,104,22,37,23),e(62,104,57,72,-25),e(100,104,97,112,27),e(142,104,132,147,-29)],sparks=[e(20,148,12,42,23),e(60,148,48,76,-25),e(100,148,88,116,27),e(140,148,122,148,-29)],boxes=[[29,64],[64,64],[104,64],[139,64]]),
      dict(name='Current ladder',birds=[e(64,32,64,96,23),e(96,128,64,96,-23)],sparks=[e(24,56,12,140,16),e(116,104,12,140,-19),e(54,152,12,140,22)],boxes=[]),
      dict(name='Four corners',birds=[e(24,56,20,44,31),e(136,56,112,140,-27),e(40,128,20,44,-31),e(116,128,112,140,27)],sparks=[e(48,152,40,68,19),e(84,152,76,104,-23),e(122,152,112,140,27)],boxes=[[30,32],[124,32]]),
      dict(name='Countdown',birds=[e(80,32),e(30,128,24,46,29),e(132,128,112,138,-31)],sparks=[e(20,148,12,44,21),e(60,148,48,76,-25),e(100,148,88,116,29),e(136,148,120,148,-33)],boxes=[[36,80],[124,80]]),
      dict(name='Rush hour',birds=[e(60,32,60,100,14),e(100,56,60,100,-18),e(70,104,60,100,22),e(90,128,60,100,-26)],sparks=[e(24,148,12,72,25),e(132,148,96,146,-29)],boxes=[[80,24]]),
      dict(name='Power grid',birds=[e(28,80,26,46,23),e(70,80,66,88,27),e(110,80,108,132,31),e(44,128,26,46,-23),e(86,128,66,88,-27),e(130,128,108,132,-31)],sparks=[e(16,148,12,26,17),e(38,148,34,48,-19),e(60,148,56,70,21),e(88,148,80,94,-23),e(106,148,102,116,25),e(136,148,124,140,-27)],boxes=[[34,48],[78,48],[122,48]]),
      dict(name='The last stone',birds=[e(28,56,26,47,25),e(70,56,66,89,29),e(110,56,108,133,33),e(44,128,26,47,-25),e(86,128,66,89,-29),e(130,128,108,133,-33)],sparks=[e(20,104,12,48,13),e(76,104,62,98,-17),e(132,104,112,148,19),e(40,152,12,48,-21),e(88,152,62,98,23),e(116,152,112,148,-25)],boxes=[[34,32],[78,32],[122,32]]),
    ]

def validate(levels):
    assert len(levels)==50
    for n,L in enumerate(levels,1):
        L.setdefault('instant',False);L['birds'].sort(key=lambda e:e[1])
        assert 1<=len(L['birds'])<=6
        assert len(L['birds'])+len(L['sparks'])<=12
        assert len(L['sparks'])+len(L['boxes'])<=11
        assert len(L['boxes'])<=4
        for i,b in enumerate(L['birds']):
            assert 10<=b[2]<=b[0]<=b[3]<=148,(n,b)
            if i>=4:assert b[1]>=L['birds'][i-4][1]+28,(n,'sprite reuse overlap')
        for a in L['birds']+L['sparks']:assert abs(a[4])<64
        for a in L['sparks']:
            for b in L['boxes']:assert abs(a[1]-b[1])>=16,(n,'char overlap')
    return levels
