# Native Odyssey² implementation

The cartridge executes Intel 8048 machine code directly. There is no PL/65
interpreter, Atari emulation, or framebuffer. The game disables the BIOS
interrupt handlers and owns its display, sound, input, and frame pacing.

## Cartridge and memory

| Resource | Use |
|---|---|
| ROM bank 0 | Game states, input, movement, collisions, overflow level records |
| ROM bank 1 | Video updates, sprite reuse, shot digits, sound effects |
| ROM bank 2 | Packed levels, fifty-entry pointer tables, and loader |
| ROM bank 3 | Display setup, title, level selection, ending |
| $B00–$BFF in every bank | Identical bank-switch and frame-wait routines |
| Internal RAM | Registers, stack, state variables, and input edge state |
| External RAM $00–$47 | Up to twelve six-byte actor records |
| External RAM $48–$4F | Up to four two-byte block positions |
| External RAM $50 | Wire pattern |

The engine uses the stock 64 bytes of internal RAM and 128 bytes of external
RAM. Actor and block data occupy at most 81 bytes of external RAM. The deepest
call chain uses seven of the processor's eight stack entries while reading overflow
level data. Gameplay uses the same frame loop as version 1.0.

The fifty level records occupy 1,705 bytes. Each record stays within a ROM
page for MOVP reads. When bank 2 fills, tagged page IDs select reserved data
pages in bank 0 through a common bank-switch routine. Only stage loading
uses that extra bank switch; frame-by-frame gameplay does not.

## Frame work

At vertical blank the renderer disables foreground graphics, restores bird
patterns and positions, updates spark X positions, places the stone character,
and refreshes changed counter digits. It then re-enables the foreground.

Four sprites draw custom pink bird shapes. The fifth and sixth birds reuse sprite
slots after the earlier birds in those slots have been displayed. A beam counter
wait places each update in the gap between the two objects. The level validator
checks that reused slots have sufficient vertical separation. The birds have
two wing poses.

Near the bottom of the field, sprite 0 is reused as the enlarged slingshot.
Foreground game logic runs after that update, while the lower screen is being
drawn. The next vertical blank starts the next display update. No bitmap or
screen buffer is copied, and no double buffering is needed.

Red sparks and gold blocks use the built-in character hardware. The grey
stone is a cropped three-by-four-pixel dot character, also drawn while loaded
between the slingshot fork tips. Colour zero selects the grey foreground entry;
bird sprite colour bits select bright magenta/pink. The HUD uses four quads.
Grid lines make the poles and wires. The background changes to green below
the playfield.

## Game rules and port adaptations

Movement uses fractional accumulators with 1/64-pixel velocity units. It is
updated once per NTSC frame. Horizontal endpoints clamp and reverse motion;
dead birds retain their record but move offscreen until the level reloads.

The rising stone moves two scanlines per frame. It can remove several birds
in one flight. A block reverses its direction; the player can catch and rethrow
it. Birds remain cleared across caught throws. Sparks or an unsuccessful lost
stone restart the level. The special convoy stage retains its original immediate
completion rule when its bird is hit.

Software overlap tests identify the particular bird, spark, or block. The
Odyssey² collision register groups all character objects together, which would
not distinguish a spark from a reflecting block. Hit areas are matched to the
smaller Odyssey² objects rather than the Atari's multicolor bitmap masks.

The first ten stages retain their target/hazard/block counts and puzzle roles.
Birds are placed on the Odyssey² grid's wire rows; blocks use an eight-pixel
character width. The long offscreen hazard train and crowded convoy are
re-spaced to avoid overlapping hardware characters. The original levels are
therefore adaptations to the console's display geometry, not pixel copies.

## Reproducing tests

`tests/playthrough.py` searches shot timing from observed actor positions and
drives a libretro O2EM core using only controller input. `tests/check_controls.py`
checks frame cadence, boundaries, pause, retry, fire latching, and sound decay.
These optional tests need NumPy, Pillow, an O2EM libretro core with the documented
read-only debug exports, and a separately supplied BIOS. The core host expects
these under the parent directory's `reference` folder, as used during development.

The MAME test also reads state only to choose inputs. It sends joystick input
through MAME's input-port API. `docs/verification.json` and the captured test
logs record the release verification, including the exact ROM SHA-256.

`tests/capture.py` replays the successful input recording and captures actual
emulated video and audio. The recording adds short holds on the title and ending
for readability. Its sound sample rate is the core's NTSC rate, 42,240 Hz;
FFmpeg resamples it for AAC encoding.

## Sound in version 1.2

Only the audio routine and its tables change from the 50-level version 1.1.
Waveforms are seeded once at note onset, then the hardware rotates them without
per-frame phase resets. A short volume envelope starts at 1, peaks at 3, and
decays to zero. The earlier version held volume 6 for all eighteen frames.
Ordinary effects use twelve audible frames; the level-clear cue uses two
notes with a brief quiet gap. Sound stops fully when its eighteen-frame timer
expires. This adds no interrupts and does not alter gameplay state or timing.
