# Softer sound effects

Version 1.2 changes the native cartridge sound routine. The gameplay video
records that sound directly; it has no loudness normalisation or equalisation.

- Peak hardware volume: 3 instead of 6.
- Gentle attack and fade instead of a constant-volume pulse.
- Waveform phase is preserved between frames.
- Lower notes replace the sharp high-frequency effects.
- Level clear has a quiet two-note rising cue.

Approximate NTSC fundamental frequencies are 123 Hz (throw), 246 Hz (return),
328 Hz (hit), 328 then 492 Hz (clear), and 82 Hz (miss).

## Recorded comparison

Both ROMs received the same controller inputs in O2EM. Measurements use
18-frame windows, remove DC, and use the same unfiltered 42,240 Hz capture.
RMS reduction describes these recordings; perceived loudness also depends
on the playback system. No physical console listening test was performed.

| Effect | RMS reduction | Old spectral centroid | New spectral centroid |
|---|---:|---:|---:|
| Throw | 10.4 dB | 1016.4 Hz | 262.4 Hz |
| Return | 10.4 dB | 1808.7 Hz | 479.3 Hz |
| Hit | 10.4 dB | 3122.0 Hz | 602.1 Hz |
| Clear | 8.4 dB | 2279.5 Hz | 832.0 Hz |
| Miss | 9.1 dB | 1373.1 Hz | 187.0 Hz |

All 50 levels still complete in O2EM and MAME at one gameplay update per
NTSC frame. Only the sound portion of ROM bank 1 differs from version 1.1.
