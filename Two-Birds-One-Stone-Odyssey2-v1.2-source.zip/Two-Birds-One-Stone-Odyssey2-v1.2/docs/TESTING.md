# Reproducing the checks

The shipped ROM contains no autoplayer. Test programs observe state and send
ordinary joystick input; they do not remove birds, award levels, or change the
game's memory.

## MAME campaign test

The release was tested with stock MAME 0.264. Configure its Odyssey² BIOS and
character ROM normally, then install the optional Python test dependencies:

```sh
python3 -m pip install numpy pillow
```

From the extracted source directory:

```sh
TBOS_ROOT="$PWD" mame odyssey2 \
  -cart build/Two-Birds-One-Stone-Odyssey2-v1.2.bin \
  -autoboot_delay 0 -autoboot_script tests/mame_campaign.lua \
  -skip_gameinfo -nothrottle -video none -sound none
```

The script reports each level and throw, then exits after the ending. `COMPLETE`
marks success. Its shot field decodes both packed-BCD bytes and reports 111 throws for this
release. The internal level index is 50 after completion; the final diagnostic
may print 51 with state 4, which denotes the ending, not another playable stage. `timing_gaps 0` means every observed active
gameplay frame advanced the logic once. Level-loading pauses are excluded.

The Lua script uses the save-item inspection API from MAME 0.264. Later MAME
versions can change this API. That affects the external test script, not the ROM.

## O2EM tests and capture

These use the libretro core through `tests/core_host.py`. The development layout
places `reference/o2em/o2em_libretro.so` and `reference/o2rom.bin` beside the source
project directory. The test core exposes this read-only accessor from `src/cpu.c`:

```c
void *retro_debug_ram(int which) {
    return which == 0 ? (void *)intRAM :
           which == 1 ? (void *)extRAM : (void *)VDCwrite;
}
```

This accessor is for the external tests only; the game does not call it.
Build that core using its normal Makefile, then run:

```sh
python3 tests/check_controls.py
python3 tests/check_expansion.py
python3 tests/check_audio.py --expect-soft
python3 tests/playthrough.py
python3 tests/capture.py
# Or capture only the four-level 45-second sampler:
python3 tests/capture_preview.py
```

Capture additionally needs FFmpeg. It writes actual emulator output, preserves
the original play speed, and records the real sound effects. A successful input
recording is also included as `tests/playthrough-inputs.npy`.

The authoritative release checks, exact ROM hash, and emulator logs are in
`docs/verification.json`, `docs/o2em-test.log`, and `docs/mame-test.log`.

The full campaigns completed all fifty levels in O2EM and MAME. The control
check covers level 9; the expansion check covers title-selection bounds,
banked level-50 records, six visible pink birds, a grey loaded/flying stone,
and 600 full-rate frames on level 50. Campaign timing excludes the brief
level-load/settling interval and checks every subsequent active frame.

Version 1.2 uses the identical full-campaign controller recording as version
1.1 and reaches the same ending in the same number of O2EM frames. All five
sound effects were triggered by input in both versions with the emulator
low-pass filter disabled. `docs/audio-before.json` and `docs/audio-after.json`
contain the measured spectra and hardware volume envelopes.
