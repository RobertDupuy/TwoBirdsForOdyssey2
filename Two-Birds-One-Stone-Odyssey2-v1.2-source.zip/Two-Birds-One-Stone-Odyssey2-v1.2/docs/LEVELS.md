# Fifty levels

The names below describe the puzzles; the ROM displays their numbers.
Stages 1–10 adapt the supplied game. Stages 11–20 are retained from version
1.0; stages 21–50 are new in version 1.1.

| Level | Puzzle | Birds | Sparks | Blocks |
|---|---|---:|---:|---:|
| 1 | One line | 2 | 0 | 0 |
| 2 | Timing | 2 | 0 | 0 |
| 3 | Crossing | 2 | 0 | 0 |
| 4 | Return to sender | 2 | 0 | 1 |
| 5 | Three circuits | 6 | 0 | 2 |
| 6 | Live wire | 1 | 1 | 0 |
| 7 | Double live wire | 1 | 2 | 0 |
| 8 | The convoy | 1 | 4 | 1 |
| 9 | Power station | 5 | 7 | 4 |
| 10 | Four flights | 4 | 0 | 0 |
| 11 | Scissor flight | 2 | 1 | 0 |
| 12 | Two return trips | 3 | 0 | 2 |
| 13 | Three in a column | 3 | 0 | 0 |
| 14 | The narrow opening | 1 | 3 | 0 |
| 15 | Twin circuits | 4 | 1 | 2 |
| 16 | Cross the current | 2 | 2 | 0 |
| 17 | The relay | 4 | 1 | 3 |
| 18 | Six wings | 6 | 0 | 3 |
| 19 | Last live wire | 2 | 3 | 0 |
| 20 | One stone to rule them all | 6 | 1 | 3 |
| 21 | Window seat | 2 | 2 | 0 |
| 22 | Return address | 4 | 0 | 3 |
| 23 | Switchback | 3 | 0 | 0 |
| 24 | The wicket | 2 | 4 | 0 |
| 25 | High and low | 4 | 1 | 2 |
| 26 | The tollgate | 4 | 3 | 3 |
| 27 | Tightropes | 2 | 1 | 0 |
| 28 | Stepping stones | 4 | 0 | 4 |
| 29 | The sweeper | 2 | 2 | 0 |
| 30 | Six returns | 6 | 0 | 3 |
| 31 | Split decision | 4 | 1 | 2 |
| 32 | Headwind | 3 | 0 | 0 |
| 33 | Safe pocket | 2 | 3 | 0 |
| 34 | Over and under | 5 | 4 | 2 |
| 35 | Two step | 4 | 0 | 2 |
| 36 | Escalator | 3 | 2 | 2 |
| 37 | Crosswind | 2 | 2 | 0 |
| 38 | Triple gates | 3 | 3 | 0 |
| 39 | Long return | 6 | 2 | 3 |
| 40 | Five flights | 5 | 2 | 4 |
| 41 | Pendulum | 2 | 3 | 0 |
| 42 | Narrow shelves | 6 | 0 | 4 |
| 43 | Drift window | 3 | 4 | 0 |
| 44 | Relay race | 5 | 4 | 4 |
| 45 | Current ladder | 2 | 3 | 0 |
| 46 | Four corners | 4 | 3 | 2 |
| 47 | Countdown | 3 | 4 | 2 |
| 48 | Rush hour | 4 | 2 | 1 |
| 49 | Power grid | 6 | 6 | 3 |
| 50 | The last stone | 6 | 6 | 3 |

All fifty stages were completed through ordinary controller input in both
O2EM and MAME. Several stages require catching and rethrowing the stone.
Birds stay cleared across caught returns, while a lost stone or spark hit
restarts the stage. Waiting for a safe opening is part of the puzzle.

The new stages mix paired flights, stacked timing windows, return-shot
sequences, moving gaps, and hazards at several heights. The final two stages
use six birds and six sparks, with the final stage splitting hazards across
two heights. The original rules, movement speed, and 60 Hz NTSC loop remain.
