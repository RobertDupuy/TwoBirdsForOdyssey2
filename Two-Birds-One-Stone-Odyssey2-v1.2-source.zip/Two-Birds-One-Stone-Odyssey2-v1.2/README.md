# Two Birds, One Stone — Odyssey²

Version 1.2 • 50 levels • NTSC • standard 8 KB cartridge

Throw one stone, clear every bird, and avoid the red sparks. Gold blocks bounce
the stone downward. Catch it with the slingshot to throw again without resetting
the birds you have already cleared. A missed stone or a spark hit restarts that
level. The shot counter continues across retries.

The original ten stages are adapted from the supplied Atari PL/65 v1.2 source.
Levels 11–50 add new combinations of moving birds, electrical hazards, and
return shots. The birds are pink and the stone is grey, both in flight and while loaded.
The graphics and code are native to the stock Odyssey². The first twenty
puzzles are retained; version 1.1 adds stages 21–50. Version 1.2 replaces
the loud, bright effects with lower-pitched tones, a gentle attack and decay,
and a soft two-note level-clear chime.

## Play

Load `Two-Birds-One-Stone-Odyssey2-v1.2.bin` as an Odyssey² cartridge in O2EM,
RetroArch's O2EM core, or MAME. An emulator needs its normal Odyssey² system BIOS;
the BIOS is not included. On compatible cartridge hardware, use the standard
8 KB / four 2 KB bank format. No RAM expansion or Videopac+ graphics are used.

Either controller works. On the title screen, left/right selects a starting
level from 1 to 50; Fire starts. Choose level 1 for the complete campaign.

| Control | Action |
|---|---|
| Left / right | Move the slingshot |
| Fire | Throw the loaded stone |
| Up + a new Fire press | Restart the current level |
| Down + a new Fire press | Pause |
| Fire while paused | Resume |
| Fire after the ending | Return to the title screen |
| Console RESET | Reboot to the title screen |

Holding Fire does not repeatedly throw. Release it before the next throw.
The ground and wires are scenery. Only the gold blocks reflect the stone.
Catch a returning stone near the open fork of the slingshot.

## What is included

- The 8,192-byte cartridge ROM.
- Native 8048 assembly, the fifty level definitions, and a Python build tool.
- A level guide, credits, and verification results.
- Optional input-only emulator test scripts and their recorded controller inputs.

Build from this directory with Python 3:

```sh
python3 tools/build.py
```

The resulting ROM is written to `build/Two-Birds-One-Stone-Odyssey2-v1.2.bin`.
The build needs only Python's standard library. It also produces four annotated
bank listings, generated assembly, symbols, and the resolved level data.
The included assembler expands bank-aware CALL/JMP and conditional branches
into ordinary Intel 8048 instructions.

## Verification and limits

The final ROM completed all fifty stages with 111 throws in both O2EM and
MAME 0.264, using ordinary controller input without modifying game memory.
The full MAME campaign had no missed gameplay updates. Separate 600-frame
tests of levels 9 and 50 also had no missed updates. Level selection covers
1–50, and the pink birds and grey loaded/flying stone were checked. Edge limits, pause/resume,
retry, held-fire behavior, and sound shutoff passed. The audio check triggers all
five effects through joystick input. Peak hardware volume is reduced from 6
to 3, and the recorded effect RMS is 8.4–10.4 dB lower than version 1.1.
See `docs/AUDIO.md` for the measurements.

This release targets NTSC at 60 gameplay updates per second. PAL timing has not
been calibrated. Testing was in emulators; the ROM has not been tested on a
physical Odyssey² or a physical multicart.

See `docs/ENGINE.md` for the hardware arrangement and
`docs/LEVELS.md` for the fifty stages.
