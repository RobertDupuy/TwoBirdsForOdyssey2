"""Capture the 45-second, four-level preview directly from the current ROM.

Uses the included verified input recording. Source emulation runs at its
native speed; only the title hold and closing card add time. No loudness
normalisation, equalisation or substitute sound is applied to the gameplay.
"""
from pathlib import Path
import ctypes as C
import json
import shutil
import subprocess
import tempfile
import wave
import numpy as np
from core_host import Host

R=Path(__file__).resolve().parents[1]
base=R.parent
work=R/'build/youtube-preview'
work.mkdir(exist_ok=True)
dest=base/'deliverables/Two-Birds-One-Stone-Odyssey2-YouTube-45s.mp4'
dest.parent.mkdir(exist_ok=True)
recording=R/'build/playthrough-inputs.npy'
if not recording.exists():recording=R/'tests/playthrough-inputs.npy'
seq=np.load(recording)
segments=[(609,1050,3),(2289,750,8),(5121,540,14)]
h=Host(base/'reference/o2em/o2em_libretro.so',base/'reference',
       {'o2em_region':'NTSC','o2em_mix_frames':'disabled','o2em_low_pass_filter':'disabled'})
h.load(R/'build/Two-Birds-One-Stone-Odyssey2-v1.2.bin')
h.lib.retro_debug_ram.restype=C.c_void_p
ir=(C.c_uint8*64).from_address(h.lib.retro_debug_ram(0))
silent=Path(tempfile.gettempdir())/'twobirds-preview-native-silent.mp4'
proc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pixel_format','rgb24',
    '-video_size','340x250','-framerate','60','-i','pipe:0','-vf',
    'scale=960:720:flags=neighbor,pad=1280:720:160:0:black,setsar=1',
    '-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',str(silent)],stdin=subprocess.PIPE)
wav=work/'preview-native.wav'
f=wave.open(str(wav),'wb');f.setparams((2,2,42240,0,'NONE','not compressed'))
written=0
for i,mask in enumerate(seq[:segments[-1][0]+segments[-1][1]]):
    h.joy={j for j in range(16) if int(mask)&(1<<j)};h.run()
    snd=b''.join(h.audio);h.audio.clear()
    for start,length,level in segments:
        if i==start:assert ir[33]==level,(i,ir[33],level)
    if i<10 or any(start<=i<start+length for start,length,_ in segments):
        proc.stdin.write(h.video.tobytes());f.writeframesraw(snd);written+=1
    if i==9:
        for _ in range(110):
            proc.stdin.write(h.video.tobytes());f.writeframesraw(bytes(704*4));written+=1
proc.stdin.close();assert proc.wait()==0;f.close()
assert written==2460
font=subprocess.check_output(['fc-match','-f','%{file}','DejaVu Sans'],text=True).strip()
filters="[0:v]setpts=PTS-STARTPTS[v0];[1:a]asetpts=PTS-STARTPTS,afade=t=out:st=40.95:d=0.05[a0];"
filters+="color=c=black:s=1280x720:r=60:d=4,drawbox=x=160:y=0:w=960:h=720:color=0x083cd5:t=fill,"
for text,y,size,colour in [('TWO BIRDS',210,76,'0xff99ff'),('ONE STONE',302,76,'white'),('ODYSSEY 2  •  50 LEVELS',450,36,'0xd5d7de')]:
    filters+=f"drawtext=fontfile='{font}':text='{text}':fontsize={size}:fontcolor={colour}:x=(w-tw)/2:y={y},"
filters+='setsar=1[v1];anullsrc=r=42240:cl=stereo,atrim=duration=4[a1];[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a]'
script=work/'native-edit.ffmpeg';script.write_text(filters)
temp_final=Path(tempfile.gettempdir())/dest.name
subprocess.run(['ffmpeg','-y','-v','error','-i',str(silent),'-i',str(wav),
    '-filter_complex_script',str(script),'-map','[v]','-map','[a]','-t','45','-r','60',
    '-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',
    '-c:a','aac','-ar','44100','-b:a','192k','-movflags','+faststart',str(temp_final)],check=True)
shutil.copyfile(temp_final,dest)
print(json.dumps({'video':str(dest),'seconds':45,'gameplay_audio':'native ROM',
                  'levels_shown':[4,5,9,15],'frames':2700}))
