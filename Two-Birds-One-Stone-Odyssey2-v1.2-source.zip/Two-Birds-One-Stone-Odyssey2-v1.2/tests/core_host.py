"""Small deterministic libretro host used to inspect the original and target."""
import ctypes as C
from pathlib import Path
import numpy as np
from PIL import Image

class Game(C.Structure):
    _fields_=[('path',C.c_char_p),('data',C.c_void_p),('size',C.c_size_t),('meta',C.c_char_p)]
class Var(C.Structure):
    _fields_=[('key',C.c_char_p),('value',C.c_char_p)]

class Host:
    def __init__(self, library, system, options=None):
        self.lib=C.CDLL(str(Path(library).resolve()))
        self.system=str(Path(system).resolve()).encode()
        self.options={k.encode():v.encode() for k,v in (options or {}).items()}
        self.keys=set(); self.joy=set(); self.frame=0; self.pixfmt=0
        self.video=None; self.audio=[]; self.keep=[]
        def env(cmd,data):
            if cmd in (9,31,30):
                C.cast(data,C.POINTER(C.c_char_p))[0]=self.system; return True
            if cmd==10:
                self.pixfmt=C.cast(data,C.POINTER(C.c_int))[0]; return True
            if cmd==15:
                v=C.cast(data,C.POINTER(Var)).contents
                if v.key in self.options: v.value=self.options[v.key]; return True
                return False
            if cmd==17: C.cast(data,C.POINTER(C.c_bool))[0]=False; return True
            if cmd==3: C.cast(data,C.POINTER(C.c_bool))[0]=False; return True
            if cmd==39: C.cast(data,C.POINTER(C.c_uint))[0]=0; return True
            if cmd in (8,11,16,18,32,34,35,36,37,44,45): return True
            return False
        def video(data,w,h,pitch):
            if not data: return
            size=4 if self.pixfmt==1 else 2
            raw=np.frombuffer(C.string_at(data,h*pitch),dtype=np.uint32 if size==4 else np.uint16).reshape(h,pitch//size)[:,:w]
            if size==4: rgb=np.stack(((raw>>16)&255,(raw>>8)&255,raw&255),-1)
            elif self.pixfmt==2: rgb=np.stack(((raw>>11)*255//31,((raw>>5)&63)*255//63,(raw&31)*255//31),-1)
            else: rgb=np.stack((((raw>>10)&31)*255//31,((raw>>5)&31)*255//31,(raw&31)*255//31),-1)
            self.video=rgb.astype('uint8')
        def audio(data,n):
            self.audio.append(C.string_at(data,n*4)); return n
        def inp(port,device,index,id):
            if device==3: return int(id in self.keys)
            if device==1: return int(id in self.joy)
            return 0
        callbacks=[('environment',C.CFUNCTYPE(C.c_bool,C.c_uint,C.c_void_p),env),
          ('video_refresh',C.CFUNCTYPE(None,C.c_void_p,C.c_uint,C.c_uint,C.c_size_t),video),
          ('audio_sample_batch',C.CFUNCTYPE(C.c_size_t,C.c_void_p,C.c_size_t),audio),
          ('audio_sample',C.CFUNCTYPE(None,C.c_int16,C.c_int16),lambda a,b:None),
          ('input_poll',C.CFUNCTYPE(None),lambda:None),
          ('input_state',C.CFUNCTYPE(C.c_int16,C.c_uint,C.c_uint,C.c_uint,C.c_uint),inp)]
        for name,typ,fn in callbacks:
            cb=typ(fn);self.keep.append(cb);getattr(self.lib,'retro_set_'+name)(cb)
        self.lib.retro_init()
        self.lib.retro_load_game.argtypes=[C.POINTER(Game)];self.lib.retro_load_game.restype=C.c_bool
        self.lib.retro_get_memory_data.argtypes=[C.c_uint];self.lib.retro_get_memory_data.restype=C.c_void_p
    def load(self,path):
        self.rom=C.create_string_buffer(Path(path).read_bytes());self.path=str(Path(path).resolve()).encode()
        self.game=Game(self.path,C.cast(self.rom,C.c_void_p),len(self.rom)-1,None)
        assert self.lib.retro_load_game(C.byref(self.game)), 'load failed'
    def run(self,n=1):
        for _ in range(n): self.lib.retro_run(); self.frame+=1
    def savepng(self,path): Image.fromarray(self.video).save(path)
    def memory(self,id=2,size=65536): return C.string_at(self.lib.retro_get_memory_data(id),size)
