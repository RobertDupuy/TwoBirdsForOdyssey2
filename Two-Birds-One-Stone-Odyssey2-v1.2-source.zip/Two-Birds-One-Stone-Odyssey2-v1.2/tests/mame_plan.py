import sys,json
from playthrough import plan
s=json.load(sys.stdin);p=plan(s['ir'],s['ex'])
if p: print(p[1]-5,p[2],p[3])
else: print(-1,0,0)
