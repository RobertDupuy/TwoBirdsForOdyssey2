"""Record actual ROM video and sound by replaying the verified controller inputs."""
from pathlib import Path
import sys,subprocess,wave,ctypes as C,tempfile,shutil,json
import numpy as np
from core_host import Host
R=Path(__file__).resolve().parents[1];base=R.parent
out=R/'build/gameplay-silent.mp4';wav=R/'build/gameplay.wav'
dest=base/'deliverables/Two-Birds-One-Stone-Odyssey2-Gameplay.mp4';dest.parent.mkdir(exist_ok=True)
h=Host(base/'reference/o2em/o2em_libretro.so',base/'reference',{'o2em_region':'NTSC','o2em_mix_frames':'disabled','o2em_low_pass_filter':'disabled'})
h.load(R/'build/Two-Birds-One-Stone-Odyssey2-v1.2.bin')
proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pixel_format','rgb24','-video_size','340x250','-framerate','60','-i','pipe:0','-vf','scale=960:720:flags=neighbor','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',str(out)],stdin=subprocess.PIPE)
f=wave.open(str(wav),'wb');f.setparams((2,2,42240,0,'NONE','not compressed'))
seq=np.load(R/'build/playthrough-inputs.npy')
samples=0
for i,mask in enumerate(seq):
    h.joy={j for j in range(16) if int(mask)&(1<<j)};h.run()
    proc.stdin.write(h.video.tobytes())
    snd=b''.join(h.audio);h.audio.clear();f.writeframesraw(snd);samples+=len(snd)//4
    if i==9 or i==len(seq)-1:
        for _ in range(120):proc.stdin.write(h.video.tobytes());f.writeframesraw(bytes(704*4));samples+=704
proc.stdin.close();assert proc.wait()==0;f.close()
h.lib.retro_debug_ram.restype=C.c_void_p
ir=(C.c_uint8*64).from_address(h.lib.retro_debug_ram(0))
assert ir[32]==4 and ir[33]==50,'Replay did not finish'
bcd=lambda v:(v>>4)*10+(v&15)
assert 100*bcd(ir[44])+bcd(ir[43])==json.loads((R/'build/playthrough.json').read_text())['shots'],'Unexpected final shot count'
temp_final=Path(tempfile.gettempdir())/dest.name
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(out),'-i',str(wav),'-c:v','copy','-c:a','aac','-b:a','128k','-movflags','+faststart','-shortest',str(temp_final)],check=True)
shutil.copyfile(temp_final,dest)
print(dest,'frames',len(seq)+240,'audio_samples',samples)
