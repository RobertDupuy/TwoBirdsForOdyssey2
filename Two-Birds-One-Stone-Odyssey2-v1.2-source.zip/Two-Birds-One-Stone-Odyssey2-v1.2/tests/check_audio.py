"""Trigger all five effects through joystick input and measure native ROM sound.

Run once per ROM/process. No game state is injected and no audio post-filter
is applied. Use --expect-soft for the v1.2 envelope/register assertions.
"""
import argparse
import ctypes as C
import hashlib
import json
import wave
from pathlib import Path
import numpy as np
from core_host import Host

R=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--rom',type=Path,default=R/'build/Two-Birds-One-Stone-Odyssey2-v1.2.bin')
parser.add_argument('--output',type=Path,default=R/'build/audio-v12')
parser.add_argument('--expect-soft',action='store_true')
args=parser.parse_args()
h=Host(R.parent/'reference/o2em/o2em_libretro.so',R.parent/'reference',
       {'o2em_region':'NTSC','o2em_mix_frames':'disabled','o2em_low_pass_filter':'disabled'})
h.load(args.rom)
h.lib.retro_debug_ram.restype=C.c_void_p
ir=(C.c_uint8*64).from_address(h.lib.retro_debug_ram(0))
vd=(C.c_uint8*256).from_address(h.lib.retro_debug_ram(2))
audio=[];volumes=[];events=[]
def run(n=1,keys=()):
    h.joy=set(keys)
    for _ in range(n):
        old=(ir[47],ir[57])
        h.run()
        audio.append(b''.join(h.audio));h.audio.clear()
        volumes.append(vd[0xaa]&15)
        if ir[57]==18 and old!=(ir[47],ir[57]):
            events.append({'frame':h.frame-1,'effect':ir[47]})
def move(x):
    for _ in range(300):
        if ir[38]==x:break
        run(1,[7 if x>ir[38] else 6])
    assert ir[38]==x
    run(2)
run(10)
for _ in range(80):
    if ir[33]==3:break
    run(1,[7])
assert ir[33]==3
run(3);run(1,[0]);run(6)
move(102);run(1,[0]);run(160)
assert ir[32]==1 and ir[33]==3 and ir[37]==1 and ir[41]==0
move(60);run(1,[0]);run(130)
assert ir[32]==1 and ir[33]==4
move(10);run(1,[0]);run(150)
assert set(e['effect'] for e in events)=={1,2,3,4,5},events
if args.expect_soft:
    assert max(volumes)==3,volumes
    for e in events:
        assert volumes[e['frame']+1]==1,(e,volumes[e['frame']:e['frame']+4])
    assert vd[0xaa]==0,'Effect did not shut off'
args.output.parent.mkdir(parents=True,exist_ok=True)
with wave.open(str(args.output.with_suffix('.wav')),'wb') as f:
    f.setparams((2,2,42240,0,'NONE','not compressed'))
    f.writeframes(b''.join(audio))
effects={}
for effect,name in enumerate(['throw','return','hit','clear','miss'],1):
    event=next(e for e in events if e['effect']==effect)
    start=event['frame']+1
    pcm=np.frombuffer(b''.join(audio[start:start+18]),dtype='<i2').reshape(-1,2).mean(axis=1)
    pcm=pcm.astype(float);pcm-=pcm.mean()
    spectrum=np.abs(np.fft.rfft(pcm*np.hanning(len(pcm))))**2
    hz=np.fft.rfftfreq(len(pcm),1/42240)
    effects[name]={'rms':round(float(np.sqrt(np.mean(pcm**2))),3),
                   'spectral_centroid_hz':round(float((spectrum*hz).sum()/spectrum.sum()),1),
                   'energy_above_1500hz':round(float(spectrum[hz>1500].sum()/spectrum.sum()),5),
                   'volume_envelope':volumes[start:start+18]}
result={'rom_sha256':hashlib.sha256(args.rom.read_bytes()).hexdigest(),
        'input_only':True,'sample_rate':42240,'frames':h.frame,
        'peak_volume_register':max(volumes),'effects':effects}
args.output.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
