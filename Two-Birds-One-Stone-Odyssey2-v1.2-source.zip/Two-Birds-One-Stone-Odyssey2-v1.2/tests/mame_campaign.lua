local root=os.getenv("TBOS_ROOT") or "."
local function q(s) return "'"..s:gsub("'", "'\\''").."'" end
local machine=manager.machine
local ram=machine.devices[":maincpu"].spaces["data"]
local port=machine.ioport.ports[":JOY.0"]
local fields={}
for name,f in pairs(port.fields) do fields[f.mask]=f end
local ext=emu.item(machine.devices[":"].items["0/m_ram"])
local current_plan=nil
local function make_plan()
 local f=io.open(root.."/build/mame-state.json","w")
 local ir={};local ex={}
 for i=0,63 do table.insert(ir,tostring(ram:read_u8(i))) end
 for i=0,127 do table.insert(ex,tostring(ext:read(i))) end
 f:write('{"ir":['..table.concat(ir,",")..'],"ex":['..table.concat(ex,",")..']}');f:close()
 os.execute("OPENBLAS_NUM_THREADS=1 python3 "..q(root.."/tests/mame_plan.py").." < "..q(root.."/build/mame-state.json").." > "..q(root.."/build/mame-plan.txt"))
 local f=io.open(root.."/build/mame-plan.txt","r")
 local x,w,k=f:read("*n","*n","*n");f:close()
 print("PLAN",x,w,k)
 if not x or x<0 then machine:exit();return {0,0,0} end
 return {ram:read_u8(33)+1,x,w}
end
local frame=0
local index=1
local mode="boot"
local left=10
local elapsed=0
local lv=-1
local prev_tick=0
local misses=0
local prev_state=-1
local prev_level=-1
local function press(v)
 for mask,f in pairs(fields) do f:set_value((v & mask) ~= 0 and 1 or 0) end
end
emu.register_frame_done(function()
 frame=frame+1
 local state=ram:read_u8(32)
 local level=ram:read_u8(33)+1
 local sx=ram:read_u8(38)
 local rd=ram:read_u8(41)
 local tick=ram:read_u8(46)
 if state==1 and prev_state==1 and level==prev_level and mode~="settle" and ((tick-prev_tick)&255)~=1 then misses=misses+1 end
 prev_tick=tick
 prev_state=state
 prev_level=level
 if level~=lv then print("LEVEL",frame,level,"STATE",state);lv=level end
 press(0)
 if state==4 then
  if mode~="end" then mode="end";left=30 end
  left=left-1
  if left==0 then machine.video:snapshot()
   local function bcd(v) return (v >> 4)*10+(v & 15) end
   local shots=bcd(ram:read_u8(43))+100*bcd(ram:read_u8(44))
   local f=io.open(root.."/build/mame-result.json","w")
   f:write('{"completed":true,"levels_completed":'..ram:read_u8(33)..',"frames":'..frame..',"shots":'..shots..',"missed_gameplay_updates":'..misses..'}');f:close()
   print("COMPLETE",frame,"shots",shots,"timing_gaps",misses);machine:exit() end
  return
 end
 if state==2 then print("FAIL",frame,"level",level,"event",index);machine.video:snapshot();machine:exit();return end
 if mode=="boot" then
  left=left-1
  if left==0 then press(16);mode="settle";left=6 end
 elseif mode=="settle" then
  left=left-1
  if left==0 then mode="aim";elapsed=0 end
 elseif mode=="aim" then
  if not current_plan then current_plan=make_plan() end
  local e=current_plan
  if not e or e[1]~=level then return end
  if sx~=e[2] then press(sx<e[2] and 2 or 8) end
  if sx==e[2] and elapsed>=e[3] then
   print("SHOT",frame,index,"sx",sx,"wait",elapsed)
   press(16);mode="fire"
  else elapsed=elapsed+1 end
 elseif mode=="fire" then
  mode="flight"
 elseif mode=="flight" then
  if state==3 then mode="next_level";index=index+1;current_plan=nil
  elseif state==1 and rd==0 then mode="aim";elapsed=0;index=index+1;current_plan=nil end
 elseif mode=="next_level" then
  if state==1 then mode="settle";left=4 end
 end
 if frame%1200==0 then machine.video:snapshot() end
 if frame>100000 then print("TIMEOUT",frame,index,state,level);machine:exit() end
end)
