"""Small, dependency-free MCS-48 assembler for this cartridge.

CALL/JMP automatically select MB0/MB1; conditional branches are expanded when
necessary. All expansion bytes and symbols are written to the listing. Ordinary
instructions use the Intel mnemonics. No emulator code runs on the console.
"""
import re

class Assembler:
    def __init__(self, symbols=None):
        self.lines=[]; self.symbols=dict(symbols or {})
    def add(self, text):
        self.lines += [s.split(';')[0].strip().lower() for s in text.splitlines()]
    def assemble(self):
        old=None
        for passno in range(30):
            pc=0x400; output={}; listing=[]
            def val(s):
                s=s.strip().replace('$','0x')
                try:return int(eval(s,{'__builtins__':{}},self.symbols))
                except NameError:
                    if passno==0:return 0
                    raise
            def jump(target):return [0xf5 if target&0x800 else 0xe5,0x04|((target>>3)&0xe0),target&255]
            for line in self.lines:
                if not line:continue
                if line.endswith(':'):
                    self.symbols[line[:-1]]=pc;continue
                if ' equ ' in line:
                    n,e=line.split(' equ ',1);self.symbols[n]=val(e);continue
                parts=line.split(None,1); op=parts[0]; args=parts[1] if len(parts)>1 else ''
                aa=[s.strip() for s in args.split(',')]
                if op=='org':pc=val(args);continue
                if op=='align':pc=(pc+val(args)-1)//val(args)*val(args);continue
                data=[]
                if op=='db':data=[val(s)&255 for s in aa]
                elif op=='jmp':data=jump(val(args))
                elif op=='call':
                    t=val(args);data=[0xf5 if t&0x800 else 0xe5,0x14|((t>>3)&0xe0),t&255,0xf5 if (pc+3)&0x800 else 0xe5]
                elif op in ('jz','jnz','jc','jnc','jt1','jnt1','jf0','jf1') or re.fullmatch('jb[0-7]',op) or op=='djnz':
                    opc={'jz':0xc6,'jnz':0x96,'jc':0xf6,'jnc':0xe6,'jt1':0x56,'jnt1':0x46,'jf0':0xb6,'jf1':0x76}.get(op)
                    t=val(aa[-1]);inv={'jz':0x96,'jnz':0xc6,'jc':0xe6,'jnc':0xf6,'jt1':0x46,'jnt1':0x56}.get(op)
                    if op.startswith('jb'):opc=0x12+int(op[2])*32
                    if op=='djnz':opc=0xe8+int(aa[0][1])
                    # Stable fixed-size expansion, including automatic page padding.
                    size=5 if inv is not None else 8
                    pad=256-(pc&255) if (pc&255)>255-size else 0
                    start=pc+pad
                    if inv is not None:data=[0]*pad+[inv,(start+5)&255]+jump(t)
                    else:data=[0]*pad+[opc,(start+5)&255]+jump(start+8)+jump(t)
                elif op=='mov':
                    d,s=aa
                    if d=='a' and s.startswith('#'):data=[0x23,val(s[1:])&255]
                    elif re.fullmatch('r[0-7]',d) and s.startswith('#'):data=[0xb8+int(d[1]),val(s[1:])&255]
                    elif d in ('@r0','@r1') and s.startswith('#'):data=[0xb0+int(d[-1]),val(s[1:])&255]
                    elif d=='a' and re.fullmatch('r[0-7]',s):data=[0xf8+int(s[1])]
                    elif s=='a' and re.fullmatch('r[0-7]',d):data=[0xa8+int(d[1])]
                    elif d=='a' and s in ('@r0','@r1'):data=[0xf0+int(s[-1])]
                    elif s=='a' and d in ('@r0','@r1'):data=[0xa0+int(d[-1])]
                    elif (d,s)==('a','t'):data=[0x42]
                    elif (d,s)==('t','a'):data=[0x62]
                    elif (d,s)==('a','psw'):data=[0xc7]
                    elif (d,s)==('psw','a'):data=[0xd7]
                elif op=='movx':data=[(0x80 if aa[0]=='a' else 0x90)+int((aa[1] if aa[0]=='a' else aa[0])[-1])]
                elif op in ('add','addc','anl','orl','xrl'):
                    d,s=aa
                    if d in ('p1','p2'):
                        data=[(0x98 if op=='anl' else 0x88)+int(d[1]),val(s[1:])&255]
                    else:
                        base={'add':0x60,'addc':0x70,'anl':0x50,'orl':0x40,'xrl':0xd0}[op]
                        if s.startswith('#'):data=[base-0x5d if op in ('add','addc') else base+3,val(s[1:])&255]
                        elif s.startswith('@r'):data=[base+int(s[-1])]
                        else:data=[base+8+int(s[-1])]
                elif op in ('inc','dec'):
                    if args=='a':data=[0x17 if op=='inc' else 0x07]
                    elif args.startswith('@r') and op=='inc':data=[0x10+int(args[-1])]
                    else:data=[(0x18 if op=='inc' else 0xc8)+int(args[-1])]
                elif op=='xch':data=[(0x20 if aa[1].startswith('@') else 0x28)+int(aa[1][-1])]
                elif op=='in':data=[8+int(aa[1][-1])]
                elif op=='outl':data=[0x38+int(aa[0][-1])]
                else:
                    key=op+(' '+args if args else '')
                    table={'nop':0,'ret':0x83,'retr':0x93,'dis i':0x15,'dis tcnti':0x35,'stop tcnt':0x65,
                        'en i':5,'strt t':0x55,'sel rb0':0xc5,'sel rb1':0xd5,'sel mb0':0xe5,'sel mb1':0xf5,
                        'clr a':0x27,'cpl a':0x37,'clr c':0x97,'cpl c':0xa7,'clr f0':0x85,'cpl f0':0x95,
                        'clr f1':0xa5,'cpl f1':0xb5,'rl a':0xe7,'rr a':0x77,'rlc a':0xf7,'rrc a':0x67,
                        'swap a':0x47,'da a':0x57,'movp a,@a':0xa3,'movp3 a,@a':0xe3,'jmpp @a':0xb3,'ins a,bus':8}
                    if key in table:data=[table[key]]
                if not data:raise ValueError(f'{pc:04x}: unknown instruction {line}')
                for b in data:
                    if pc in output:raise ValueError(f'Overlap at {pc:04x} ({line})')
                    output[pc]=b;pc+=1
                listing.append((pc-len(data),bytes(data),line))
            sig=(tuple(sorted(self.symbols.items())),tuple(output.items()))
            if sig==old:
                self.output=output;self.listing=listing;return output
            old=sig
        raise ValueError('Assembler did not converge')
