#!/usr/bin/env python3
"""Build the standard 8 KB cartridge using only Python 3."""
import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from asm48 import Assembler
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from levels import original_levels,new_levels,expansion_levels,validate

LEVEL_COUNT=50
ROM_NAME='Two-Birds-One-Stone-Odyssey2-v1.2.bin'

NAMES='state level nbirds nsparks nboxes live sx rx ry rd oldjoy shotslo shotshi delay frame sound count flags index temp temp2 temp3 temp4 temp5 huddirty soundtime ticklo tickhi spare0 spare1 spare2 spare3'.split()
S={n:32+i for i,n in enumerate(NAMES)}
S.update(fireedge=24,load_data=0xb50,render_frame=0xb10,setup_play=0xb30,show_title=0xb30,audio_frame=0xb70,wait_frame=0xb90,bird_shapes=0x800,sling_shape=0x870)
S.update(level_count=LEVEL_COUNT,last_level=LEVEL_COUNT-1)

COMMON='''
org 0x400
 jmp boot
org 0xb00
boot:
 anl p1,#252
 jmp 0x410
org 0xb10
 orl p1,#3
 anl p1,#253
 call 0x410
 anl p1,#252
 ret
org 0xb30
 orl p1,#3
 call 0x410
 anl p1,#252
 ret
org 0xb50
 orl p1,#3
 anl p1,#254
 call 0x410
 anl p1,#252
 ret
org 0xb70
 orl p1,#3
 anl p1,#253
 call 0x900
 anl p1,#252
 ret
org 0xb90
 orl p1,#0x90
 anl p1,#0xb7
 mov r0,#0xa1
wf_active:
 movx a,@r0
 jb3 wf_active
wf_blank:
 movx a,@r0
 jb3 wf_done
 jmp wf_blank
wf_done:
 ret
org 0xbc0
 ; Overflow level records live in bank 0; A survives both bank switches.
 anl p1,#252
 call 0x7c0
 orl p1,#2
 ret
'''

def birdshapes():
    # Facing right; bit 0 is the left side on the 8244.
    bird=[0x30,0x58,0xf8,0x7c,0x3e,0x1c,0x14,0x00]
    sling=[0x81,0x42,0x24,0x18,0x18,0x18,0x18,0x3c]
    out=['org 0x800',' mov r0,#frame',' mov a,@r0',' anl a,#8',' mov r3,#248',' mov r4,#62',' jz wings_ready',' mov r3,#254',' mov r4,#56','wings_ready:',' mov r0,#0x80',' mov r1,#4','shape_loop:']
    for i,b in enumerate(bird):out += [' mov a,r3' if i==2 else ' mov a,r4' if i==4 else ' mov a,#'+str(b),' movx @r0,a',' inc r0']
    out+=[' djnz r1,shape_loop',' ret','org 0x870']
    # The independent grey stone character supplies the loaded stone too.
    out+=[' mov r0,#0x80',' mov a,#0x81',' movx @r0,a',' inc r0']
    for b in sling[1:]:out+=[' mov a,#'+str(b),' movx @r0,a',' inc r0']
    out+=[' ret']
    return '\n'.join(out)

def levelbank(levels):
    # Pack records within pages: MOVP cannot read across a page boundary.
    # Page IDs 0x18..0x1a select pages 8..10 in bank 0.  The regular
    # renderer and game loop are unchanged; banking happens only at level load.
    capacities={5:248,6:248,7:248,8:248,9:248,10:128,24:248,25:248,26:248}
    pages={i:[] for i in capacities}; locations=[];page_ids=list(pages);pi=0
    for L in levels:
        birds=L['birds'];sparks=L['sparks'];boxes=L['boxes']
        mask=0x80
        for b in birds:
            row=(b[1]+16-24)//24
            if 0<=row<8:mask |=1<<row
        data=[len(birds),len(sparks),len(boxes),int(L['instant']),mask]
        for x,y,lo,hi,speed in birds+sparks:data +=[x,y,lo,hi,abs(speed)|(128 if speed<0 else 0)]
        for x,y in boxes:data += [x,y]
        pg=page_ids[pi]
        if len(pages[pg])+len(data)>capacities[pg]:
            pi+=1
            if pi>=len(page_ids):raise ValueError('level data exceeds reserved ROM pages')
            pg=page_ids[pi]
        locations.append((len(pages[pg]),pg));pages[pg]+=data
    out=['org 0x410', 'load:',' mov a,#0xae',' outl p1,a',' mov r0,#level',' mov a,@r0',' add a,#0x94',' movp a,@a',' mov r6,a',
         ' mov a,@r0',f' add a,#{0x94+len(levels)}',' movp a,@a',' mov r7,a',' call read_data',' mov r0,#nbirds',' mov @r0,a',' mov r0,#live',' mov @r0,a',
         ' call read_data',' mov r0,#nsparks',' mov @r0,a',' mov r0,#nbirds',' add a,@r0',' mov r0,#count',' mov @r0,a',' mov r5,a',
         ' call read_data',' mov r0,#nboxes',' mov @r0,a',' call read_data',' mov r0,#flags',' mov @r0,a',' call read_data',' mov r1,#80',' movx @r1,a',
         ' mov r1,#0','load_entity:',' mov r4,#4','load_four:',' call read_data',' movx @r1,a',' inc r1',' djnz r4,load_four',' call read_data',' mov r3,a',' anl a,#127',' movx @r1,a',' inc r1',' mov a,r3',' anl a,#128',' movx @r1,a',' inc r1',' djnz r5,load_entity',
         ' mov r0,#nboxes',' mov a,@r0',' jz load_done',' rl a',' mov r5,a',' mov r1,#72','load_boxes:',' call read_data',' movx @r1,a',' inc r1',' djnz r5,load_boxes','load_done:',' ret',
         'org 0x494','db '+','.join(str(x[0]) for x in locations),'db '+','.join(str(x[1]) for x in locations)]
    # Dispatch uses a separate fixed page, avoiding the loader's pointer table.
    out+=['org 0xa80','read_data:',' mov a,r7',' jb4 read_other_bank',' xrl a,#5',' jz rd5',' mov a,r7',' xrl a,#6',' jz rd6',' mov a,r7',' xrl a,#7',' jz rd7',' mov a,r7',' xrl a,#8',' jz rd8',' mov a,r7',' xrl a,#9',' jz rd9',' call 0xafa',' jmp rd_ret']
    for p in range(5,10):out += [f'rd{p}:',f' call {p*256+250}',' jmp rd_ret']
    out+=['rd_ret:',' inc r6',' ret','read_other_bank:',' call 0xbc0',' jmp rd_ret']
    extra=['org 0x7c0','extra_data:',' mov a,r7',' xrl a,#24',' jz extra8',' mov a,r7',' xrl a,#25',' jz extra9',' call 0xafa',' ret','extra8:',' call 0x8fa',' ret','extra9:',' call 0x9fa',' ret']
    for p,data in pages.items():
        target=out if p<16 else extra
        address=(p&15)*256
        if data:target +=[f'org {address}','db '+','.join(map(str,data))]
        target +=[f'org {address+250}',' mov a,r6',' movp a,@a',' ret']
    print(f'Level records: {sum(map(len,pages.values()))} bytes; pages '+str({hex(k):len(v) for k,v in pages.items() if v}))
    return '\n'.join(out),'\n'.join(extra)

GLYPHS={c:i for i,c in enumerate('0123456789:$ ?L P'.replace(' ',''))} # explicit mapping below
GLYPHS=dict(zip('0123456789',range(10)))
GLYPHS.update(dict(zip('WERTUIOQSDFGHJKAZXCVBM',range(17,39))))
GLYPHS.update({'L':14,'P':15,'N':45})
GLYPHS.update({' ':12,'.':39,'-':40,'+':16,'?':13,'/':46,'Y':44})
def charcode(c):return GLYPHS[c]
def putchar(reg,x,y,c,color=14):
    return f'mov r0,#{reg}\nmov r3,#{x}\nmov r4,#{y}\nmov r5,#{charcode(c) if isinstance(c,str) else c}\nmov r6,#{color}\ncall put_char\n'
def quad(reg,x,y,text,color=14):
    return ''.join(putchar(reg+i*4,x,y,c,color) for i,c in enumerate(text.ljust(4)))

def setupbank():
    out='''org 0x410
setup:
 mov a,#0xb7
 outl p1,a
 mov r0,#0xa0
 clr a
 movx @r0,a
 mov r0,#0
 mov r7,#240
clear_vdc:
 movx @r0,a
 inc r0
 djnz r7,clear_vdc
 mov r0,#0
 mov r7,#32
hide_objects:
 mov a,#248
 movx @r0,a
 inc r0
 movx @r0,a
 inc r0
 inc r0
 inc r0
 djnz r7,hide_objects
 mov r0,#0xa3
 mov a,#14
 movx @r0,a
 mov r0,#state
 mov a,@r0
 xrl a,#1
 jnz title
 ; Static grid wires and two poles.
 mov a,#0xe7
 outl p1,a
 mov r1,#80
 movx a,@r1
 mov r0,#0xc0
 mov r7,#9
wires:
 movx @r0,a
 inc r0
 djnz r7,wires
 mov a,#127
 mov r0,#0xe0
 movx @r0,a
 mov r0,#0xe9
 movx @r0,a
 mov r0,#nbirds
 mov a,@r0
 mov r7,a
 rl a
 add a,r7
 rl a
 mov r1,a
 mov r0,#temp
 mov @r0,a
 mov r0,#nsparks
 mov a,@r0
 mov r0,#temp2
 mov @r0,a
 mov r0,#temp3
 mov @r0,#16
spark_init:
 mov r0,#temp2
 mov a,@r0
 jz boxes_init
 dec a
 mov @r0,a
 mov r0,#temp
 mov a,@r0
 mov r1,a
 add a,#6
 mov @r0,a
 movx a,@r1
 mov r3,a
 inc r1
 movx a,@r1
 mov r4,a
 mov r5,#41
 mov r6,#2
 mov r0,#temp3
 mov a,@r0
 add a,#4
 mov @r0,a
 add a,#-4
 mov r0,a
 call put_char
 jmp spark_init
boxes_init:
 mov r0,#temp
 mov @r0,#72
 mov r0,#nboxes
 mov a,@r0
 mov r0,#temp2
 mov @r0,a
box_init:
 mov r0,#temp2
 mov a,@r0
 jz play_hud
 dec a
 mov @r0,a
 mov r0,#temp
 mov a,@r0
 mov r1,a
 add a,#2
 mov @r0,a
 movx a,@r1
 mov r3,a
 inc r1
 movx a,@r1
 mov r4,a
 mov r5,#47
 mov r6,#6
 mov r0,#temp3
 mov a,@r0
 add a,#4
 mov @r0,a
 add a,#-4
 mov r0,a
 call put_char
 jmp box_init
play_hud:
'''
    out+=quad(0x40,10,16,'LV  ',6)+quad(0x50,74,16,f'/{LEVEL_COUNT} ',6)+quad(0x60,10,224,'SHOT',6)+quad(0x70,94,224,'0000')
    out+='''mov r0,#level
 mov a,@r0
 inc a
 mov r7,a
 mov r5,#0
level_decimal:
 mov a,r7
 add a,#-10
 jnc level_digits
 mov r7,a
 inc r5
 jmp level_decimal
level_digits:
 mov r0,#0x48
 mov r3,#10
 mov r4,#16
 mov r6,#6
 call put_char
 mov a,r7
 mov r5,a
 mov r0,#0x4c
 mov r3,#10
 mov r4,#16
 mov r6,#6
 call put_char
 mov a,#0xb7
 outl p1,a
 mov r0,#0xa0
 mov a,#42
 movx @r0,a
 ret
'''
    # put_char preserves r7 and uses the mixed external-read / VDC-write mode.
    out+='''org 0x800
put_char:
 mov a,r4
 movx @r0,a
 inc r0
 mov a,r3
 movx @r0,a
 inc r0
 mov a,r5
 anl a,#32
 rr a
 rr a
 rr a
 rr a
 rr a
 mov r2,a
 mov a,r5
 rl a
 rl a
 rl a
 anl a,#248
 mov r5,a
 mov a,r4
 rr a
 cpl a
 inc a
 add a,r5
 movx @r0,a
 inc r0
 mov a,r2
 jc put_color
 xrl a,#1
put_color:
 anl a,#1
 orl a,r6
 movx @r0,a
 ret
'''
    out+='org 0x850\ntitle:\nmov a,#0xb7\noutl p1,a\nmov r0,#state\nmov a,@r0\nxrl a,#4\njz ending\n'
    for line,y in [('2BIRDS',56),('1STONE',88)]:
        for i,c in enumerate(line):out+=putchar(0x10+((y==88)*6+i)*4,40+i*12,y,c,6 if i==0 else 14)
    out+=quad(0x40,52,144,'FIRE',6)
    out+=quad(0x50,52,112,'L   ',10)
    out+='call title_level\njmp credit\n'
    out+='org 0x9a0\nending:\n'
    for j,(line,y) in enumerate([(f'ALL{LEVEL_COUNT}',56),('CLEAR',88)]):
        for i,c in enumerate(line):out+=putchar(0x10+(j*5+i)*4,48+i*12,y,c,6 if j==0 else 14)
    out+=quad(0x40,52,144,'FIRE',6)
    # Ending shots use the same quad as the game's counter, then the audio bank updates it.
    out+=quad(0x60,10,224,'SHOT',6)+quad(0x70,94,224,'0000')
    out+='call ending_score\njmp title_finish\n'
    out+='org 0x600\nending_score:\n'
    for i,(var,swap) in enumerate([('shotshi',True),('shotshi',False),('shotslo',True),('shotslo',False)]):
        out+=f'mov r0,#{var}\nmov a,@r0\n'+('swap a\n' if swap else '')+'anl a,#15\nmov r5,a\n'+f'mov r0,#{0x70+i*4}\nmov r3,#94\nmov r4,#224\nmov r6,#14\ncall put_char\n'
    out+='ret\n'
    return out

def main():
    original=ROOT/'src/original-levels.txt'
    levels=validate(original_levels(original)+new_levels()+expansion_levels())
    assert len(levels)==LEVEL_COUNT
    (ROOT/'build').mkdir(exist_ok=True)
    (ROOT/'build/levels.json').write_text(json.dumps(levels,indent=2))
    data,extra=levelbank(levels)
    sources=[(ROOT/'src/main.a48').read_text()+'\n'+extra,(ROOT/'src/video.a48').read_text()+birdshapes(),data,setupbank()]
    # Remaining title subroutines are placed in gaps by the generator below.
    sources[3]+='''
org 0x700
title_level:
 mov r0,#level
 mov a,@r0
 inc a
 mov r7,a
 mov r5,#0
tl_decimal:
 mov a,r7
 add a,#-10
 jnc tl_digits
 mov r7,a
 inc r5
 jmp tl_decimal
tl_digits:
 mov r0,#0x58
 mov r3,#52
 mov r4,#112
 mov r6,#10
 call put_char
 mov a,r7
 mov r5,a
 mov r0,#0x5c
 mov r3,#52
 mov r4,#112
 mov r6,#10
 call put_char
 ret
credit:
'''+quad(0x60,24,208,'POLY',8)+quad(0x70,88,208,'MARS',8)+'''
title_finish:
 mov r0,#0xa0
 mov a,#34
 movx @r0,a
 ret
'''
    rom=bytearray();syms=[]
    for b,source in enumerate(sources):
        a=Assembler(S);a.add(source);a.add(COMMON);a.assemble()
        assert max(a.output)<0xc00,(b,hex(max(a.output)))
        bank=bytearray(2048)
        for p,v in a.output.items():
            assert 0x400<=p<0xc00
            bank[p-0x400]=v
        rom+=bank;syms.append(a.symbols)
        (ROOT/f'build/bank{b}.lst').write_text('\n'.join(f'{p:04X} {d.hex(" "):<30} {s}' for p,d,s in a.listing))
        (ROOT/f'build/bank{b}.a48').write_text(source+COMMON)
        print(f'Bank {b}: {len(a.output)} / 2048 bytes used')
    out=ROOT/'build'/ROM_NAME;out.write_bytes(rom)
    (ROOT/'build/symbols.json').write_text(json.dumps(syms,indent=2))
    print(out.name, len(rom), hashlib.sha256(rom).hexdigest())
if __name__=='__main__':main()
