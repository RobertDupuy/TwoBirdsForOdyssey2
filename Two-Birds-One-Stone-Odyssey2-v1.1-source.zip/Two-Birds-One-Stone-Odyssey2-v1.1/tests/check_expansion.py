"""Input-only checks for level 50, banked records, both colours and full-rate play."""
import ctypes as C
import json
from pathlib import Path
import numpy as np
from core_host import Host

R=Path(__file__).resolve().parents[1]
base=R.parent
h=Host(base/'reference/o2em/o2em_libretro.so',base/'reference',{'o2em_region':'NTSC','o2em_mix_frames':'disabled'})
h.load(R/'build/Two-Birds-One-Stone-Odyssey2-v1.1.bin')
h.lib.retro_debug_ram.restype=C.c_void_p
ir=(C.c_uint8*64).from_address(h.lib.retro_debug_ram(0))
ex=(C.c_uint8*256).from_address(h.lib.retro_debug_ram(1))
vd=(C.c_uint8*256).from_address(h.lib.retro_debug_ram(2))

def run(n=1,keys=()):
    h.joy=set(keys)
    h.run(n)

run(10)
run(40,[6])
assert ir[33]==0,'Title selector fell below level 1'
for _ in range(600):
    if ir[33]==49:break
    run(1,[7])
assert ir[33]==49,'Level 50 is not selectable'
run(80,[7])
assert ir[33]==49,'Title selector went beyond level 50'
run(3)
h.savepng(R/'build/title-50.png')
run(1,[0]);run(8)
assert ir[32]==1 and ir[33]==49
assert (ir[34],ir[35],ir[36],ir[37])==(6,6,3,6)
level=json.loads((R/'build/levels.json').read_text())[49]
for i,(x,y,lo,hi,speed) in enumerate(level['birds']+level['sparks']):
    actual=list(ex[i*6:i*6+6])
    assert actual[1:5]==[y,lo,hi,abs(speed)],(i,actual)
assert list(ex[72:78])==[v for box in level['boxes'] for v in box]
gaps=[]
for f in range(600):
    before=ir[46];run()
    if (ir[46]-before)&255!=1:gaps.append(f)
assert not gaps,gaps
# These are the stock O2EM NTSC palette values after RGB565 conversion.
pink=np.all(h.video==[255,153,255],axis=2)
grey=np.all(h.video==[90,109,106],axis=2)
assert pink.sum()>=500,'Not all six pink birds are visible'
assert grey.sum()==24,'Loaded stone is not the independent grey character'
assert vd[0x3f]&14==0,'Stone is not using the grey palette entry'
h.savepng(R/'build/colour-check-loaded.png')
run(1,[0]);run(5)
grey=np.all(h.video==[90,109,106],axis=2)
assert grey.sum()==24 and np.nonzero(grey)[0].max()<176,'Flying stone colour/position'
h.savepng(R/'build/colour-check-flying.png')
result={'title_selection_1_to_50':'PASS','banked_level_50_records':'PASS',
        'six_pink_birds':'PASS','grey_stone_loaded_and_flying':'PASS',
        'level_50_frames_checked':600,'missed_gameplay_updates':len(gaps)}
(R/'build/expansion-test.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
