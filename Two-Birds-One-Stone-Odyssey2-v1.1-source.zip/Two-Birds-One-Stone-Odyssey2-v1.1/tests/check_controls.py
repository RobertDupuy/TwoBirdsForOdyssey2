"""Regression checks for input latching, pause, restart and worst-case timing."""
import sys,ctypes as C,json
from pathlib import Path
from core_host import Host
R=Path(__file__).resolve().parents[1];base=R.parent
h=Host(base/'reference/o2em/o2em_libretro.so',base/'reference',{'o2em_region':'NTSC'})
h.load(R/'build/Two-Birds-One-Stone-Odyssey2-v1.1.bin')
h.lib.retro_debug_ram.restype=C.c_void_p
ir=(C.c_uint8*64).from_address(h.lib.retro_debug_ram(0))
ex=(C.c_uint8*256).from_address(h.lib.retro_debug_ram(1))
vd=(C.c_uint8*256).from_address(h.lib.retro_debug_ram(2))
def run(n=1,keys=()):h.joy=set(keys);h.run(n)
run(10)
# Select the busiest stage by ordinary title-screen input.
while ir[33]<8:run(1,[7])
run(1,[0]);run(6)
assert ir[33]==8 and ir[34]==5 and ir[35]==7 and ir[36]==4
gaps=[]
for f in range(600):
    tick=ir[46];run()
    if (ir[46]-tick)&255!=1:gaps.append(f)
assert not gaps,gaps
run(320,[6]);assert ir[38]==10
run(320,[7]);assert ir[38]==142
run(1,[0,5]);run(3)
assert ir[32]==5
frozen=bytes(ex[:80]);tick=ir[46]
run(120);assert bytes(ex[:80])==frozen and ir[46]==tick
run(1,[0]);run(3);assert ir[32]==1 and ir[41]==0
run(1,[0,4]);run(5)
assert ir[32]==1 and ir[37]==5 and ir[38]==76
# Hold the trigger through an unsuccessful flight and automatic retry.
before=ir[43];run(1);run(240,[0]);assert ir[43]==before+1
run(25);assert vd[0xaa]==0,'sound did not decay'
result={'ntsc_frames_checked':600,'missed_logic_updates':len(gaps),'left_right_limits':'PASS','pause_resume':'PASS','restart':'PASS','fire_edge_latch':'PASS','sound_stops':'PASS'}
(R/'build/controls-test.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
