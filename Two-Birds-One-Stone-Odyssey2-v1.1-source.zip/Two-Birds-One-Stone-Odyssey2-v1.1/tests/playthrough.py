"""Input-only campaign test. A search predicts shot timing from observed RAM.

No game RAM/ROM is modified. Every move, catch, shot, and level transition is
performed by ordinary controller input through the emulator's libretro API.
"""
import sys,json,ctypes as C,time
from pathlib import Path
import numpy as np
from core_host import Host
ROOT=Path(__file__).resolve().parents[1]
SY=json.loads((ROOT/'build/symbols.json').read_text())[0]

def forecast(entities,n=2400):
    ent=[list(e) for e in entities]; out=np.zeros((n+1,len(ent)),dtype=np.int16)
    out[0]=[e[0] for e in ent]
    for t in range(1,n+1):
        for i,e in enumerate(ent):
            x,y,lo,hi,rate,phase=e
            if y!=248:
                rem=(phase&63)+rate
                e[5]=(phase&128)|(rem&63)
                if rem>=64:
                    if phase&128:
                        x-=1
                        if x<lo:x=lo;e[5]&=63
                    else:
                        x+=1
                        if x>=hi:x=hi;e[5]|=128
                    e[0]=x
            out[t,i]=x
    return out

def trajectory(x,boxes):
    y=174;direction=1;ys=[]
    for t in range(200):
        y+=-2 if direction==1 else 2
        if direction==1 and y<8:return np.array(ys),False
        if direction==2 and y>=176:return np.array(ys),True
        ys.append(y)
        if direction==1:
            for bx,by in boxes:
                if -2<=x-bx<8 and -4<=y-by<14:
                    direction=2;y=by+14;break
    raise AssertionError('stone failed to return')

def plan(ir,ex,limit=1200):
    nb=ir[SY['nbirds']];count=ir[SY['count']];sx=ir[SY['sx']]
    ent=[list(ex[i*6:i*6+6]) for i in range(count)]
    boxes=[list(ex[72+i*2:74+i*2]) for i in range(ir[SY['nboxes']])]
    alive=[i for i in range(nb) if ent[i][1]!=248]
    xs=forecast(ent,limit+500);best=None
    for x in range(15,148):
        travel=2*abs(sx-(x-5))
        times=np.arange(travel,travel+limit,dtype=np.int32)
        ys,bounce=trajectory(x,boxes)
        safe=np.ones(len(times),dtype=bool);kills=np.zeros(len(times),dtype=np.int16)
        for i,e in enumerate(ent):
            if e[1]==248:continue
            steps=np.nonzero((ys-e[1]>=-4)&(ys-e[1]<16))[0]+1
            if not len(steps):continue
            xx=xs[times[:,None]+steps[None,:],i]
            hit=np.any((x-xx>=-2)&(x-xx<8),axis=1)
            if i<nb:kills+=hit
            else:safe&=~hit
        win=(kills==len(alive))
        good=safe & ((kills>0) if bounce else win)
        if not alive:good=safe & (not bounce)
        if ir[SY['flags']]:good=safe & win
        robust=good.copy()
        for d in range(1,4):robust &= np.roll(good,d)&np.roll(good,-d)
        if robust.any():good=robust
        inds=np.flatnonzero(good)
        if not len(inds):continue
        # Finish first; otherwise remove more birds, then minimise waiting.
        scores=(win[inds]&(not bounce))*100000+kills[inds]*3000-times[inds]
        j=inds[np.argmax(scores)];score=int(scores.max())
        if best is None or score>best[0]:best=(score,x,int(times[j]),int(kills[j]),bool(bounce))
    return best

def main():
    root=ROOT.parent
    h=Host(root/'reference/o2em/o2em_libretro.so',root/'reference',{'o2em_region':'NTSC','o2em_mix_frames':'disabled'})
    h.load(ROOT/'build/Two-Birds-One-Stone-Odyssey2-v1.1.bin')
    h.lib.retro_debug_ram.restype=C.c_void_p
    ir=(C.c_uint8*64).from_address(h.lib.retro_debug_ram(0));ex=(C.c_uint8*256).from_address(h.lib.retro_debug_ram(1))
    events=[];inputs=[];frames=[];timing_gaps=[];active_streak=0;record='--record' in sys.argv
    def run(n=1,joy=()):
        nonlocal active_streak
        h.joy=set(joy)
        for _ in range(n):
            before=(ir[32],ir[33],ir[46]);h.run();inputs.append(sum(1<<j for j in joy))
            active_streak=active_streak+1 if before[:2]==(ir[32],ir[33]) and ir[32]==1 else 0
            if active_streak>=6 and ((ir[46]-before[2])&255)!=1:timing_gaps.append(h.frame)
            if record:frames.append(h.video.copy())
    run(10);run(1,[0]);run(5)
    attempts={};last=-1;shots=0
    while ir[SY['state']]!=4 and h.frame<200000:
        lv=ir[SY['level']]
        if lv!=last:
            print('LEVEL',lv+1,'frame',h.frame,flush=True);last=lv
            run(4)
            h.savepng(ROOT/f'build/level-{lv+1:02}.png')
        if ir[SY['state']]!=1 or ir[SY['rd']]!=0:run();continue
        t=time.time();p=plan(ir,ex)
        if not p:
            print('NO PLAN',lv+1,'live',ir[SY['live']],'entities',list(ex[:ir[SY['count']]*6]),flush=True)
            (ROOT/'build/failed-state.json').write_text(json.dumps({'iram':list(ir),'xram':list(ex)}))
            break
        _,x,wait,kills,bounce=p
        print(' shot',shots+1,'x',x,'wait',wait,'kills',kills,'bounce',bounce,'search',round(time.time()-t,2),flush=True)
        sx=ir[SY['sx']];target=x-5;spent=0
        while ir[SY['sx']]!=target:
            run(1,[7 if target>ir[SY['sx']] else 6]);spent+=1
            assert spent<300
        if wait>spent:run(wait-spent)
        events.append({'level':lv+1,'frame':h.frame,'stone_x':x,'wait':wait,'predicted_kills':kills,'bounce':bounce})
        run(1,[0]);shots+=1
        run(1)
        # Let this flight finish; remaining under the launch column catches returns.
        for _ in range(180):
            if ir[SY['state']]!=1 or ir[SY['rd']]==0:break
            run()
        attempts[lv]=attempts.get(lv,0)+1
        if attempts[lv]>35:print('TOO MANY ATTEMPTS',lv+1);break
    run(30)
    result={'completed':ir[SY['state']]==4,'levels_completed':50 if ir[SY['state']]==4 else ir[SY['level']],'current_level':None if ir[SY['state']]==4 else ir[SY['level']]+1,'frames':h.frame,'shots':shots,'missed_gameplay_updates':len(timing_gaps),'events':events}
    (ROOT/'build/playthrough.json').write_text(json.dumps(result,indent=2))
    np.save(ROOT/'build/playthrough-inputs.npy',np.array(inputs,dtype=np.uint16))
    if record:np.save(ROOT/'build/playthrough-video.npy',np.array(frames))
    h.savepng(ROOT/'build/ending.png')
    print(json.dumps({k:v for k,v in result.items() if k!='events'}),flush=True)
if __name__=='__main__':main()
